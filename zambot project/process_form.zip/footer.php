</main>


<footer class="footer">
  <div class="container">
    <a href="#" class="logo">
      <span class="logo-text">E-com</span>
    </a>
    <p class="copyright">© 2024 E-com —
      <a href="#" class="twitter-link" rel="noopener noreferrer" target="_blank">@zambot</a>
    </p>
  </div>
</footer>


  </body>
</html>